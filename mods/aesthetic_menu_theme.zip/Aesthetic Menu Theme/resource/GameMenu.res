"GameMenu"
{
	"1"
	{
		"label" "Return"
		"command" "ResumeGame"
		"OnlyInGame" "1"
	}
	"2"
	{
		"label" "Disconnect"
		"command" "Disconnect"
		"OnlyInGame" "1"
	}
	"3"
	{
		"label" "Players"
		"command" "OpenPlayerListDialog"
		"OnlyInGame" "1"
		"notsingle" "1"
	}
	"4"
	{
		"label" "New Game"
		"command" "OpenNewGameDialog"
		"notmulti" "1"
		"notsingle" "1"
	}
	"5"
	{
		"label" "Save Game"
		"command" "OpenSaveGameDialog"
		"notmulti" "1"
		"OnlyInGame" "1"
	}
	"6"
	{
		"label" "Load Game"
		"command" "OpenLoadGameDialog"
		"notmulti" "1"
	}
//	"7"
//	{
//		"name" "LoadDemo"
//		"label" "#GameUI_GameMenu_PlayDemo"
//		"command" "OpenLoadDemoDialog"
//	}
	"8"
	{
		"label" "Options"
		"command" "OpenOptionsDialog"
	}
	"9"
	{
		"label" "Mods"
		"command" "OpenChangeGameDialog"
		"notsteam" "1"
		"notsingle" "1"
		"notmulti" "1"
	}
	"10"
	{
		"label" "Quit"
		"command" "Quit"
	}
}
