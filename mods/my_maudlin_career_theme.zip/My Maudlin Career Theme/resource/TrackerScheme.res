//
// TRACKER SCHEME RESOURCE FILE
//
// sections:
//		colors			- all the colors used by the scheme
//		basesettings	- contains settings for app to use to draw controls
//		fonts			- list of all the fonts used by app
//		borders			- description of all the borders
//
// notes:
// 		hit ctrl-alt-shift-R in the app to reload this file
//
Scheme
{
	//////////////////////// COLORS ///////////////////////////
	Colors
	{
		// base colors
"BaseText" "217 190 190 255"
"BrightBaseText" "255 235 235 245"
"SelectedText" "255 255 255 255"
"DimBaseText" "120 95 95 255"
"LabelDimText" "140 110 110 245"
"ControlText" "217 190 190 255"
"BrightControlText" "255 245 245 250"

// text color for options and buttons
"DisabledText1" "90 60 60 210"
"DisabledText2" "40 25 25 255"
"DimListText" "140 110 110 255"

"ControlBG" "196 38 38 255"
"ControlDarkBG" "74 63 63 255"
"WindowBG" "74 63 63 210"
"ListBG" "74 63 63 200"

"SelectionBG" "196 38 38 255"
"SelectionBG2" "40 20 20 255"

"TitleText" "217 190 190 250"
"TitleDimText" "217 190 190 220"
"TitleBG" "74 63 63 000"
"TitleDimBG" "74 63 63 000"

"SliderTickColor" "217 190 190 250"
"SliderTrackColor" "196 38 38 250"

"BorderBright" "217 190 190 40"
"BorderDark" "74 63 63 120"
"BorderSelection" "196 38 38 150"

// border for button
"ButtonArmedBgColor" "196 38 38 26"
	}

	///////////////////// BASE SETTINGS ////////////////////////
	// default settings for all panels
	// controls use these to determine their settings
	BaseSettings
	{
		"FgColor"			"ControlText"
		"BgColor"			"ControlBG"
		"LabelBgColor"		"ControlBG"
		"SubPanelBgColor"	"ControlBG"

		"DisabledFgColor1"		"DisabledText1" 
		"DisabledFgColor2"		"DisabledText2"			// set this to the BgColor if you don't want it to draw

		"TitleBarFgColor"			"TitleText"
		"TitleBarDisabledFgColor"	"TitleDimText"
		"TitleBarBgColor"			"TitleBG"
		"TitleBarDisabledBgColor"	"TitleDimBG"

		"TitleBarIcon"				"resource/icon_steam"
		"TitleBarDisabledIcon"		"resource/icon_steam_disabled"

		"TitleButtonFgColor"			"BorderBright"
		"TitleButtonBgColor"			"ControlBG"
		"TitleButtonDisabledFgColor"	"TitleDimText"
		"TitleButtonDisabledBgColor"	"TitleDimBG"

		"TextCursorColor"			"BaseText"			// color of the blinking text cursor in text entries
		"URLTextColor"				"BrightBaseText"	// color that URL's show up in chat window

		Menu
		{
			"FgColor"			"DimBaseText"
			"BgColor"			"ControlBG"
			"ArmedFgColor"		"BrightBaseText"
			"ArmedBgColor"		"SelectionBG"
			"DividerColor"		"BorderDark"

			"TextInset"			"6"
		}

		MenuButton	  // the little arrow on the side of boxes that triggers drop down menus
		{
			"ButtonArrowColor"	"DimBaseText"		// color of arrows
		   	"ButtonBgColor"		"WindowBG"			// bg color of button. same as background color of text edit panes 
			"ArmedArrowColor"	"BrightBaseText"	// color of arrow when mouse is over button
			"ArmedBgColor"		"DimBaseText"		// bg color of button when mouse is over button
		}

		Slider
		{
			"SliderFgColor"		"ControlBG"			// handle with which the slider is grabbed
			"SliderBgColor"		"ControlDarkBG"		// area behind handle
		}

		ScrollBarSlider
		{
			"BgColor"					"ControlBG"		// this isn't really used
			"ScrollBarSliderFgColor"	"ControlBG"		// handle with which the slider is grabbed
			"ScrollBarSliderBgColor"	"ControlDarkBG"	// area behind handle
			"ButtonFgColor"				"DimBaseText"	// color of arrows
		}


		// text edit windows
		"WindowFgColor"				"BaseText"		// off-white
		"WindowBgColor"				"WindowBG"		// redundant. can we get rid of WindowBgColor and just use WindowBG?
		"WindowDisabledFgColor"		"DimBaseText"
		"WindowDisabledBgColor"		"ListBG"		// background of chat conversation
		"SelectionFgColor"			"SelectedText"	// fg color of selected text
		"SelectionBgColor"			"SelectionBG"
		"ListSelectionFgColor"		"SelectedText"
		"ListBgColor"				"ListBG"		// background of server browser control, etc
		"BuddyListBgColor"			"ListBG"		// background of buddy list pane
		
		// App-specific stuff
		"ChatBgColor"				"WindowBG"

		// status selection
		"StatusSelectFgColor"		"BrightBaseText"
		"StatusSelectFgColor2"		"BrightControlText"	// this is the color of the friends status

		// checkboxes
		"CheckButtonBorder1"   		"BorderDark"		// the left checkbutton border
		"CheckButtonBorder2"   		"BorderBright"		// the right checkbutton border
		"CheckButtonCheck"			"BrightControlText"	// color of the check itself
		"CheckBgColor"				"ListBG"

		// buttons (default fg/bg colors are used if these are not set)
//		"ButtonArmedFgColor"
//		"ButtonArmedBgColor"
//		"ButtonDepressedFgColor"	"BrightControlText"
//		"ButtonDepressedBgColor"

		// buddy buttons
		BuddyButton
		{
			"FgColor1"				"ControlText"
			"FgColor2"				"DimListText"
			"ArmedFgColor1"			"BrightBaseText"
			"ArmedFgColor2"			"BrightBaseText"
			"ArmedBgColor"			"SelectionBG"
		}

		Chat
		{
			"TextColor"				"BrightControlText"
			"SelfTextColor"			"BaseText"
			"SeperatorTextColor"	"DimBaseText"
		}

InGameDesktop
{
    "MenuColor"                "196 38 38 255"
    "ArmedMenuColor"           "217 190 190 255"
    "BlurMenuColor"            "217 190 190 255"
    "DepressedMenuColor"       "74 63 63 255"
    "MenuHintColor"            "74 63 63 255"
    "WidescreenBarColor"       "0 0 0 0"
    "MenuItemVisibilityRate"   "0.00"  // time it takes for one menu item to appear
    "MenuItemHeight"           "48" // this is proportional to resolution
    "GameMenuInset"            "110"
}

		"SectionTextColor"		"BrightControlText"	// text color for IN-GAME, ONLINE, OFFLINE sections of buddy list
		"SectionDividerColor"	"BorderDark"		// color of line that runs under section name in buddy list
		
		"ProportionalBaseWidth" "640"		// if the display resolution is above this,
		"ProportionalBaseHeight" "480"		//  ui elements will be scaled.
		"ProportionalBaseWidthHD" "1280"		
		"ProportionalBaseHeightHD" "720"		
	}

	Fonts
{
	"Default"
	{
		"1"
		{
			"name" "Tahoma"
			"tall" "14"
			"weight" "400"
			"antialias" "1"
		}
	}

	"DefaultBold"
	{
		"1"
		{
			"name" "Tahoma"
			"tall" "14"
			"weight" "700"
			"antialias" "1"
		}
	}

	"DefaultSmall"
	{
		"1"
		{
			"name" "Tahoma"
			"tall" "12"
			"weight" "400"
		}
	}

	"DefaultSmallBold"
	{
		"1"
		{
			"name" "Tahoma"
			"tall" "12"
			"weight" "700"
		}
	}

	"MenuLarge"
	{
		"1"
		{
			"name" "Trebuchet MS"
			"tall" "24"
			"weight" "800"
			"antialias" "1"
		}
	}

	"MenuHintLarge"
	{
		"1"
		{
			"name" "Trebuchet MS"
			"tall" "18"
			"weight" "400"
			"antialias" "1"
		}
	}

	"UiHeadline"
	{
		"1"
		{
			"name" "Verdana"
			"tall" "16"
			"weight" "700"
			"antialias" "1"
		}
	}

	"Marlett"
	{
		"1"
		{
			"name" "Marlett"
			"tall" "14"
			"symbol" "1"
		}
	}

	"GameConsole_Mono"
	{
		"1"
		{
			"name" "Courier New"
			"tall" "13"
			"weight" "400"
		}
	}
}
Borders
{
	BaseBorder		"FlatBorder"
	ComboBoxBorder	"FlatBorder"
	BrowserBorder	"FlatBorder"
	ButtonBorder		"FlatBorder"
	FrameBorder		"FlatBorder"
	TabBorder		"FlatBorder"
	MenuBorder		"FlatBorder"

	FlatBorder
	{
		"inset" "0 0 1 1"

		Left
		{
			"1"
			{
				"color" "BorderDark"
				"offset" "0 0"
			}
		}

		Top
		{
			"1"
			{
				"color" "BorderDark"
				"offset" "0 0"
			}
		}

		Right
		{
			"1"
			{
				"color" "BorderBright"
				"offset" "0 0"
			}
		}

		Bottom
		{
			"1"
			{
				"color" "BorderBright"
				"offset" "0 0"
			}
		}
	}

	ButtonKeyFocusBorder
	{
		"inset" "0 0 1 1"

		Left
		{
			"1" { "color" "BorderSelection" "offset" "0 0" }
		}

		Top
		{
			"1" { "color" "BorderSelection" "offset" "0 0" }
		}

		Right
		{
			"1" { "color" "BorderSelection" "offset" "0 0" }
		}

		Bottom
		{
			"1" { "color" "BorderSelection" "offset" "0 0" }
		}
	}

	ButtonDepressedBorder
	{
		"inset" "1 1 1 1"

		Left   { "1" { "color" "BorderDark" "offset" "0 0" } }
		Top    { "1" { "color" "BorderDark" "offset" "0 0" } }
		Right  { "1" { "color" "BorderDark" "offset" "0 0" } }
		Bottom { "1" { "color" "BorderDark" "offset" "0 0" } }
	}
}
	
	//////////////////////// CUSTOM FONT FILES /////////////////////////////
	//
	// specifies all the custom (non-system) font files that need to be loaded to service the above described fonts
	CustomFontFiles
	{
		"4"		"resource/linux_fonts/DejaVuSans.ttf"
		"5"		"resource/linux_fonts/DejaVuSans-Bold.ttf"
		"6"		"resource/linux_fonts/DejaVuSans-BoldOblique.ttf"
		"7"		"resource/linux_fonts/DejaVuSans-Oblique.ttf"
		"8"		"resource/linux_fonts/LiberationSans-Regular.ttf"
		"9"		"resource/linux_fonts/LiberationSans-Bold.ttf"
		"10"		"resource/linux_fonts/LiberationMono-Regular.ttf"
		"11"		"resource/linux_fonts/FiraSans-Regular.ttf"
		"12"		"resource/linux_fonts/FiraSans-Medium.ttf"
	}
}
